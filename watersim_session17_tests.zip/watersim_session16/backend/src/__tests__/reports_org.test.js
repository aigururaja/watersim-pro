/**
 * WaterSim Pro — GET /api/v1/reports (org-level, cursor-paginated)
 * Session 16: Tests cover the keyset-cursor pagination rewrite, filter params,
 * saved-report CRUD, and Excel export endpoints.
 *
 * Requires a live PostgreSQL database (TEST_DATABASE_URL or DATABASE_URL).
 * If no DB is present the whole suite is skipped gracefully so CI stays green
 * on environments that only run unit tests.
 */

'use strict';

const { request, app, registerAndLogin, makeProject, makeFlowsheet, loginAs, createTestUser } =
  require('./helpers');

const SKIP =
  process.env.CI !== 'true' &&
  !process.env.DATABASE_URL &&
  !process.env.TEST_DATABASE_URL;

// ─── Helpers ──────────────────────────────────────────────────────────────────

/** Seed a minimal completed simulation_run directly via SQL (dev/test only). */
async function seedCompletedRun(pool, { orgId, projectId, flowsheetId, userId, completedAt }) {
  const { v4: uuidv4 } = require('uuid');
  const runId = uuidv4();
  await pool.query(
    `INSERT INTO simulation_runs
       (id, flowsheet_id, created_by, mode, status, started_at, completed_at, results)
     VALUES ($1, $2, $3, 'steady_state', 'completed', NOW() - interval '2 minutes', $4,
       '{"summary":{"compliant":true,"totalFlow":1000},"costBreakdown":{},"warnings":[]}'::jsonb)`,
    [runId, flowsheetId, userId, completedAt || new Date().toISOString()]
  );
  return runId;
}

// ─── Suite ────────────────────────────────────────────────────────────────────

describe('Reports Org API (Session 16 — cursor pagination)', () => {
  if (SKIP) {
    it.skip('No DB available — skipping reports_org tests', () => {});
    return;
  }

  let token;
  let agent;
  let projectId;
  let flowsheetId;
  let userId;

  // We import the pool lazily so tests that skip never try to connect.
  let pool;

  beforeAll(async () => {
    pool = require('../db/pool').pool; // raw pg.Pool — used for seed helpers

    ({ token, userId } = await registerAndLogin({
      orgSlug: `reports-test-${Date.now()}`,
      email:   `reports-${Date.now()}@test.example`,
    }));

    agent = await loginAs({
      email:    `reports-${Date.now()}@test.example`,
      password: 'TestPass123!',
      orgSlug:  `reports-test-${Date.now()}`,
    });

    // Simpler: just use supertest with explicit auth header
    const makeReq = (method, path) =>
      request(app)[method](path).set('Authorization', `Bearer ${token}`);

    // Create a project + flowsheet to attach runs to
    const projRes = await makeReq('post', '/api/v1/projects')
      .send({ name: 'Test Plant', projectType: 'wastewater' });
    projectId = projRes.body.id || projRes.body.data?.id;

    const fsRes = await makeReq('post', `/api/v1/projects/${projectId}/flowsheets`)
      .send({ name: 'Main Flowsheet', canvas_data: {} });
    flowsheetId = fsRes.body.id || fsRes.body.data?.id;
  }, 30_000);

  // ── Auth guard ─────────────────────────────────────────────────────────────

  describe('GET /api/v1/reports — auth', () => {
    it('returns 401 without a token', async () => {
      const res = await request(app).get('/api/v1/reports');
      expect(res.status).toBe(401);
    });

    it('returns 200 with a valid token (empty org)', async () => {
      const res = await request(app)
        .get('/api/v1/reports')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
    });
  });

  // ── Response shape ─────────────────────────────────────────────────────────

  describe('GET /api/v1/reports — response shape', () => {
    it('returns { total, runs, nextCursor } shape', async () => {
      const res = await request(app)
        .get('/api/v1/reports')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(typeof res.body.total).toBe('number');
      expect(Array.isArray(res.body.runs)).toBe(true);
      expect(Object.prototype.hasOwnProperty.call(res.body, 'nextCursor')).toBe(true);
    });

    it('nextCursor is null when no more results', async () => {
      const res = await request(app)
        .get('/api/v1/reports?limit=100')
        .set('Authorization', `Bearer ${token}`);
      // With ≤ 100 total runs (new org) there should be no next page
      expect(res.body.nextCursor).toBeNull();
    });

    it('each run includes required camelCase fields', async () => {
      // Seed one run so we have something to inspect
      if (!projectId || !flowsheetId) return;

      await seedCompletedRun(pool, { projectId, flowsheetId, userId });

      const res = await request(app)
        .get('/api/v1/reports')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);

      if (res.body.runs.length === 0) return; // skip if seed wasn't reachable

      const run = res.body.runs[0];
      expect(run).toHaveProperty('id');
      expect(run).toHaveProperty('mode');
      expect(run).toHaveProperty('flowsheetId');
      expect(run).toHaveProperty('flowsheetName');
      expect(run).toHaveProperty('projectId');
      expect(run).toHaveProperty('projectName');
      expect(run).toHaveProperty('createdBy');
      expect(run).toHaveProperty('completedAt');
      expect(run).toHaveProperty('summary');
      expect(run).toHaveProperty('saved');
    });
  });

  // ── Cursor pagination ──────────────────────────────────────────────────────

  describe('GET /api/v1/reports — cursor pagination', () => {
    it('respects the limit param', async () => {
      const res = await request(app)
        .get('/api/v1/reports?limit=1')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.runs.length).toBeLessThanOrEqual(1);
    });

    it('rejects limit > 100', async () => {
      const res = await request(app)
        .get('/api/v1/reports?limit=101')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(422);
    });

    it('rejects an invalid (non-ISO) cursor', async () => {
      const res = await request(app)
        .get('/api/v1/reports?cursor=not-a-date')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(422);
    });

    it('accepts a valid ISO cursor and returns older rows', async () => {
      // Seed two runs with distinct timestamps
      if (!projectId || !flowsheetId) return;

      const t1 = new Date(Date.now() - 60_000).toISOString(); // 1 min ago
      const t2 = new Date(Date.now() - 30_000).toISOString(); // 30 s ago

      await seedCompletedRun(pool, { projectId, flowsheetId, userId, completedAt: t1 });
      await seedCompletedRun(pool, { projectId, flowsheetId, userId, completedAt: t2 });

      // Fetch page 1 (newest first)
      const page1 = await request(app)
        .get('/api/v1/reports?limit=1')
        .set('Authorization', `Bearer ${token}`);
      expect(page1.status).toBe(200);
      expect(page1.body.nextCursor).not.toBeNull();

      // Fetch page 2 using the cursor
      const page2 = await request(app)
        .get(`/api/v1/reports?limit=1&cursor=${encodeURIComponent(page1.body.nextCursor)}`)
        .set('Authorization', `Bearer ${token}`);
      expect(page2.status).toBe(200);
      expect(Array.isArray(page2.body.runs)).toBe(true);

      // Page 2 runs should be older than page 1 runs
      if (page1.body.runs.length && page2.body.runs.length) {
        const p1Time = new Date(page1.body.runs[0].completedAt).getTime();
        const p2Time = new Date(page2.body.runs[0].completedAt).getTime();
        expect(p2Time).toBeLessThan(p1Time);
      }
    });

    it('total remains stable across pages (reflects full unfiltered count)', async () => {
      if (!projectId || !flowsheetId) return;

      const page1 = await request(app)
        .get('/api/v1/reports?limit=1')
        .set('Authorization', `Bearer ${token}`);
      if (!page1.body.nextCursor) return; // not enough data

      const page2 = await request(app)
        .get(`/api/v1/reports?limit=1&cursor=${encodeURIComponent(page1.body.nextCursor)}`)
        .set('Authorization', `Bearer ${token}`);

      expect(page2.body.total).toBe(page1.body.total);
    });

    it('nextCursor is null on the last page', async () => {
      // Request a page that must be the last (cursor set to ancient time)
      const ancientCursor = '2000-01-01T00:00:00Z';
      const res = await request(app)
        .get(`/api/v1/reports?cursor=${encodeURIComponent(ancientCursor)}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.runs).toEqual([]);
      expect(res.body.nextCursor).toBeNull();
    });

    it('does not return duplicate rows when paginating', async () => {
      if (!projectId || !flowsheetId) return;

      const allIds = new Set();
      let cursor = null;
      let pageCount = 0;

      do {
        const url = cursor
          ? `/api/v1/reports?limit=2&cursor=${encodeURIComponent(cursor)}`
          : '/api/v1/reports?limit=2';
        const res = await request(app)
          .get(url)
          .set('Authorization', `Bearer ${token}`);
        expect(res.status).toBe(200);
        for (const run of res.body.runs) {
          expect(allIds.has(run.id)).toBe(false); // no duplicate
          allIds.add(run.id);
        }
        cursor = res.body.nextCursor;
        pageCount++;
      } while (cursor && pageCount < 10); // safety cap
    });
  });

  // ── Filter params ──────────────────────────────────────────────────────────

  describe('GET /api/v1/reports — filter validation', () => {
    it('rejects an invalid mode value', async () => {
      const res = await request(app)
        .get('/api/v1/reports?mode=invalid_mode')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(422);
    });

    it('rejects an invalid compliance value', async () => {
      const res = await request(app)
        .get('/api/v1/reports?compliance=maybe')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(422);
    });

    it('rejects a non-UUID projectId', async () => {
      const res = await request(app)
        .get('/api/v1/reports?projectId=not-a-uuid')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(422);
    });

    it('accepts valid mode=steady_state filter', async () => {
      const res = await request(app)
        .get('/api/v1/reports?mode=steady_state')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      // All returned runs must match the requested mode
      for (const run of res.body.runs) {
        expect(run.mode).toBe('steady_state');
      }
    });

    it('accepts valid compliance=pass filter', async () => {
      const res = await request(app)
        .get('/api/v1/reports?compliance=pass')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
    });

    it('accepts a valid UUID projectId filter', async () => {
      if (!projectId) return;
      const res = await request(app)
        .get(`/api/v1/reports?projectId=${projectId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      for (const run of res.body.runs) {
        expect(run.projectId).toBe(projectId);
      }
    });
  });

  // ── Org isolation ──────────────────────────────────────────────────────────

  describe('GET /api/v1/reports — org isolation', () => {
    it('users in different orgs cannot see each other\'s runs', async () => {
      const otherUser = await registerAndLogin({
        orgSlug: `other-org-${Date.now()}`,
        email:   `other-${Date.now()}@test.example`,
      });

      // Seed a run in the original org
      if (projectId && flowsheetId) {
        await seedCompletedRun(pool, { projectId, flowsheetId, userId });
      }

      // The other org should see zero runs (they have no projects)
      const res = await request(app)
        .get('/api/v1/reports')
        .set('Authorization', `Bearer ${otherUser.token}`);
      expect(res.status).toBe(200);
      expect(res.body.total).toBe(0);
      expect(res.body.runs).toEqual([]);
    });
  });

  // ── Saved reports ──────────────────────────────────────────────────────────

  describe('POST /api/v1/reports/saved', () => {
    it('returns 422 when runId is missing', async () => {
      const res = await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({});
      expect(res.status).toBe(422);
    });

    it('returns 422 when runId is not a UUID', async () => {
      const res = await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({ runId: 'not-a-uuid' });
      expect(res.status).toBe(422);
    });

    it('returns 404 when run does not exist in org', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({ runId: uuidv4() });
      expect(res.status).toBe(404);
    });

    it('rejects label longer than 255 characters', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({ runId: uuidv4(), label: 'x'.repeat(256) });
      expect(res.status).toBe(422);
    });

    it('saves a run and returns the saved record (integration)', async () => {
      if (!projectId || !flowsheetId) return;
      const runId = await seedCompletedRun(pool, { projectId, flowsheetId, userId });

      const res = await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({ runId, label: 'My Bookmark', notes: 'Good run' });
      expect(res.status).toBe(201);
      expect(res.body.run_id).toBe(runId);
      expect(res.body.label).toBe('My Bookmark');
    });

    it('upserts on conflict — updating label/notes', async () => {
      if (!projectId || !flowsheetId) return;
      const runId = await seedCompletedRun(pool, { projectId, flowsheetId, userId });

      await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({ runId, label: 'Original' });

      const res = await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({ runId, label: 'Updated' });
      expect(res.status).toBe(201);
      expect(res.body.label).toBe('Updated');
    });
  });

  describe('DELETE /api/v1/reports/saved/:runId', () => {
    it('returns 422 for a non-UUID runId', async () => {
      const res = await request(app)
        .delete('/api/v1/reports/saved/not-a-uuid')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(422);
    });

    it('returns 200 even if the run was never saved (idempotent)', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app)
        .delete(`/api/v1/reports/saved/${uuidv4()}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    it('removes the saved record (integration)', async () => {
      if (!projectId || !flowsheetId) return;
      const runId = await seedCompletedRun(pool, { projectId, flowsheetId, userId });

      await request(app)
        .post('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`)
        .send({ runId, label: 'To delete' });

      const delRes = await request(app)
        .delete(`/api/v1/reports/saved/${runId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(delRes.status).toBe(200);

      // Run should no longer appear as saved
      const listRes = await request(app)
        .get('/api/v1/reports')
        .set('Authorization', `Bearer ${token}`);
      const run = listRes.body.runs.find(r => r.id === runId);
      if (run) expect(run.saved).toBe(false);
    });
  });

  describe('GET /api/v1/reports/saved', () => {
    it('returns only runs saved by the current user', async () => {
      const res = await request(app)
        .get('/api/v1/reports/saved')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('returns 401 without auth', async () => {
      const res = await request(app).get('/api/v1/reports/saved');
      expect(res.status).toBe(401);
    });
  });

  // ── Excel export ───────────────────────────────────────────────────────────

  describe('GET /api/v1/reports/:runId/excel', () => {
    it('returns 422 for a non-UUID runId', async () => {
      const res = await request(app)
        .get('/api/v1/reports/not-a-uuid/excel')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(422);
    });

    it('returns 404 for a UUID that does not belong to the org', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app)
        .get(`/api/v1/reports/${uuidv4()}/excel`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(404);
    });

    it('returns 401 without auth', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app).get(`/api/v1/reports/${uuidv4()}/excel`);
      expect(res.status).toBe(401);
    });

    it('returns an xlsx file for a valid run (integration)', async () => {
      if (!projectId || !flowsheetId) return;
      const runId = await seedCompletedRun(pool, { projectId, flowsheetId, userId });

      const res = await request(app)
        .get(`/api/v1/reports/${runId}/excel`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toContain(
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      );
      expect(res.headers['content-disposition']).toMatch(/attachment/);
    });
  });

  // ── Comparison Excel export ────────────────────────────────────────────────

  describe('POST /api/v1/reports/compare/excel', () => {
    it('returns 422 when runIds array has fewer than 2 items', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app)
        .post('/api/v1/reports/compare/excel')
        .set('Authorization', `Bearer ${token}`)
        .send({ runIds: [uuidv4()] });
      expect(res.status).toBe(422);
    });

    it('returns 422 when runIds array has more than 6 items', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app)
        .post('/api/v1/reports/compare/excel')
        .set('Authorization', `Bearer ${token}`)
        .send({ runIds: Array.from({ length: 7 }, uuidv4) });
      expect(res.status).toBe(422);
    });

    it('returns 404 when none of the run UUIDs belong to the org', async () => {
      const { v4: uuidv4 } = require('uuid');
      const res = await request(app)
        .post('/api/v1/reports/compare/excel')
        .set('Authorization', `Bearer ${token}`)
        .send({ runIds: [uuidv4(), uuidv4()] });
      expect(res.status).toBe(404);
    });
  });
});
