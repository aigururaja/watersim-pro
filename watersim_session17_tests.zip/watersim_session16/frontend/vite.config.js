import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],

  server: {
    proxy: {
      '/api': 'http://localhost:4000',
    },
  },

  // ── Vitest configuration ─────────────────────────────────────────────────
  test: {
    environment: 'jsdom',
    globals:     true,
    setupFiles:  ['./src/__tests__/setup.js'],
    coverage: {
      provider:  'v8',
      reporter:  ['text', 'lcov', 'html'],
      include:   ['src/**/*.{js,jsx}'],
      exclude:   ['src/main.jsx', 'src/**/*.test.*', 'src/**/__tests__/**'],
    },
  },
});
