/**
 * WaterSim Pro — VirtualTable component tests
 * Session 16: Performance — drop-in virtualised table for ReportsPage
 *
 * Run with:  npx vitest run
 * Framework: Vitest + @testing-library/react + jsdom
 *
 * Install if not present:
 *   npm i -D @testing-library/react @testing-library/user-event jsdom
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import VirtualTable from '../../components/VirtualTable';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const makeRows = (n) =>
  Array.from({ length: n }, (_, i) => ({
    id:          `row-${i}`,
    projectName: `Project ${i}`,
    mode:        i % 2 === 0 ? 'steady_state' : 'dynamic',
    completedAt: new Date(Date.now() - i * 60_000).toISOString(),
  }));

const COLUMNS = [
  { key: 'projectName', header: 'Project',    flex: 2 },
  { key: 'mode',        header: 'Mode',       width: 140 },
  { key: 'completedAt', header: 'Completed',  flex: 1,
    render: (row) => new Date(row.completedAt).toLocaleDateString() },
];

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('VirtualTable', () => {
  beforeEach(() => {
    // jsdom doesn't scroll, so stub IntersectionObserver and scrollTop behaviour
    global.IntersectionObserver = vi.fn().mockImplementation(() => ({
      observe: vi.fn(), disconnect: vi.fn(),
    }));
  });

  // ── Rendering ───────────────────────────────────────────────────────────

  describe('rendering', () => {
    it('renders column headers', () => {
      render(
        <VirtualTable
          rows={makeRows(5)}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
        />
      );
      expect(screen.getByText('Project')).toBeDefined();
      expect(screen.getByText('Mode')).toBeDefined();
      expect(screen.getByText('Completed')).toBeDefined();
    });

    it('renders row data for a small list', () => {
      const rows = makeRows(3);
      render(
        <VirtualTable
          rows={rows}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
        />
      );
      expect(screen.getByText('Project 0')).toBeDefined();
      expect(screen.getByText('Project 1')).toBeDefined();
      expect(screen.getByText('Project 2')).toBeDefined();
    });

    it('uses the custom render function for a column', () => {
      const rows = makeRows(1);
      render(
        <VirtualTable
          rows={rows}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
        />
      );
      // The Completed column uses toLocaleDateString — it should not show the raw ISO string
      const rawIso = rows[0].completedAt;
      expect(screen.queryByText(rawIso)).toBeNull();
    });

    it('shows the emptyState slot when rows is empty', () => {
      render(
        <VirtualTable
          rows={[]}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
          emptyState={<div>No runs found</div>}
        />
      );
      expect(screen.getByText('No runs found')).toBeDefined();
    });

    it('does not show emptyState when rows are present', () => {
      render(
        <VirtualTable
          rows={makeRows(2)}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
          emptyState={<div>No runs found</div>}
        />
      );
      expect(screen.queryByText('No runs found')).toBeNull();
    });

    it('renders a skeleton overlay when loading=true', () => {
      const { container } = render(
        <VirtualTable
          rows={[]}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
          loading
        />
      );
      // Skeleton is typically rendered as an overlay — check the container has something
      // beyond just the header (component uses a Skeleton component from ../Skeleton)
      expect(container.firstChild).toBeDefined();
    });

    it('does not render a skeleton when loading=false', () => {
      render(
        <VirtualTable
          rows={makeRows(2)}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
          loading={false}
        />
      );
      // Row data should be visible, not hidden behind a skeleton
      expect(screen.getByText('Project 0')).toBeDefined();
    });
  });

  // ── Virtualisation ───────────────────────────────────────────────────────

  describe('virtualisation', () => {
    it('does not render all rows for a large dataset', () => {
      const rows = makeRows(500);
      render(
        <VirtualTable
          rows={rows}
          columns={[{ key: 'projectName', header: 'Project' }]}
          getRowKey={(r) => r.id}
          rowHeight={52}
          containerHeight={520}
        />
      );
      // With 500 rows only a viewport slice should be in the DOM
      const cells = screen.queryAllByText(/^Project \d+$/);
      expect(cells.length).toBeLessThan(500);
    });

    it('keeps the sticky header in the DOM regardless of scroll', () => {
      const rows = makeRows(100);
      const { container } = render(
        <VirtualTable
          rows={rows}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
          rowHeight={52}
          containerHeight={520}
        />
      );
      // Header should always be present
      expect(screen.getByText('Project')).toBeDefined();
    });
  });

  // ── Interaction ──────────────────────────────────────────────────────────

  describe('onRowClick', () => {
    it('calls onRowClick with the correct row when a row is clicked', () => {
      const rows = makeRows(3);
      const onRowClick = vi.fn();
      render(
        <VirtualTable
          rows={rows}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
          onRowClick={onRowClick}
        />
      );
      fireEvent.click(screen.getByText('Project 1'));
      expect(onRowClick).toHaveBeenCalledWith(rows[1], expect.anything());
    });

    it('does not throw when onRowClick is not provided', () => {
      const rows = makeRows(2);
      render(
        <VirtualTable
          rows={rows}
          columns={COLUMNS}
          getRowKey={(r) => r.id}
        />
      );
      expect(() => fireEvent.click(screen.getByText('Project 0'))).not.toThrow();
    });
  });

  // ── Alternating row colours ───────────────────────────────────────────────

  describe('alternating row fills', () => {
    it('applies distinct background to even and odd rows', () => {
      const rows = makeRows(4);
      const { container } = render(
        <VirtualTable
          rows={rows}
          columns={[{ key: 'projectName', header: 'Project' }]}
          getRowKey={(r) => r.id}
          rowHeight={52}
          containerHeight={520}
        />
      );
      // The component applies alternating fills via index % 2 — we can check
      // that the rendered row elements have differing classes or inline styles
      const rowEls = container.querySelectorAll('[data-row-index]');
      if (rowEls.length >= 2) {
        // At minimum the two adjacent rows should differ in some styling attribute
        const style0 = rowEls[0].getAttribute('class') || rowEls[0].getAttribute('style');
        const style1 = rowEls[1].getAttribute('class') || rowEls[1].getAttribute('style');
        expect(style0).not.toBe(style1);
      }
    });
  });

  // ── Default props ─────────────────────────────────────────────────────────

  describe('default prop handling', () => {
    it('uses rowHeight=52 and containerHeight=520 by default without error', () => {
      expect(() =>
        render(
          <VirtualTable
            rows={makeRows(5)}
            columns={COLUMNS}
            getRowKey={(r) => r.id}
          />
        )
      ).not.toThrow();
    });

    it('renders correctly with only required props', () => {
      expect(() =>
        render(<VirtualTable rows={[]} columns={COLUMNS} getRowKey={(r) => r.id} />)
      ).not.toThrow();
    });
  });
});
