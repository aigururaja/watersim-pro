/**
 * WaterSim Pro — Vitest global test setup
 * Loaded before every test file via vitest.setupFiles.
 */

import '@testing-library/jest-dom';
import { vi, afterEach } from 'vitest';
import { cleanup } from '@testing-library/react';

// Automatically unmount and clean up React trees after each test
afterEach(() => {
  cleanup();
});

// ── Browser API stubs ──────────────────────────────────────────────────────────

// jsdom doesn't implement ResizeObserver
global.ResizeObserver = vi.fn().mockImplementation(() => ({
  observe:    vi.fn(),
  unobserve:  vi.fn(),
  disconnect: vi.fn(),
}));

// jsdom doesn't implement IntersectionObserver
global.IntersectionObserver = vi.fn().mockImplementation(() => ({
  observe:    vi.fn(),
  unobserve:  vi.fn(),
  disconnect: vi.fn(),
}));

// Silence console.error for known React warnings in tests (optional)
// Uncomment if your test output is noisy:
// const consoleError = console.error.bind(console);
// beforeAll(() => {
//   console.error = (msg, ...args) => {
//     if (typeof msg === 'string' && msg.includes('Warning:')) return;
//     consoleError(msg, ...args);
//   };
// });
// afterAll(() => { console.error = consoleError; });
