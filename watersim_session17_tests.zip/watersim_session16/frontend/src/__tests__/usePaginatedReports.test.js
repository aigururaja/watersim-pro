/**
 * WaterSim Pro — usePaginatedReports hook tests
 * Session 16: Performance — cursor-based infinite-scroll data hook
 *
 * Run with:  npx vitest run
 * Framework: Vitest + @testing-library/react + msw (mock service worker)
 *
 * Install if not present:
 *   npm i -D @testing-library/react @testing-library/react-hooks msw jsdom
 */

import {
  describe, it, expect, vi, beforeEach, afterEach, afterAll, beforeAll,
} from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';
import { http, HttpResponse } from 'msw';
import { setupServer } from 'msw/node';

// The hook uses axios via our api utility.  We mock the module so no real HTTP
// calls are made and so we can control the response shape precisely.
vi.mock('../../utils/api', () => ({
  default: {
    get: vi.fn(),
  },
}));

import api from '../../utils/api';
import { usePaginatedReports } from '../../hooks/usePaginatedReports';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const makeRun = (id, completedAt) => ({
  id,
  mode: 'steady_state',
  flowsheetId:   'fs-1',
  flowsheetName: 'Main',
  projectId:     'proj-1',
  projectName:   'Test Plant',
  createdBy:     'Test User',
  completedAt:   completedAt || new Date().toISOString(),
  summary:       { compliant: true },
  saved:         false,
});

const PAGE_1_RUNS = [makeRun('run-1', '2025-12-01T10:00:00Z'), makeRun('run-2', '2025-11-30T09:00:00Z')];
const PAGE_2_RUNS = [makeRun('run-3', '2025-11-28T08:00:00Z'), makeRun('run-4', '2025-11-27T07:00:00Z')];

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('usePaginatedReports', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Stub IntersectionObserver (jsdom doesn't implement it)
    global.IntersectionObserver = vi.fn().mockImplementation(() => ({
      observe:   vi.fn(),
      unobserve: vi.fn(),
      disconnect: vi.fn(),
    }));
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  // ── Initial load ─────────────────────────────────────────────────────────

  describe('initial load', () => {
    it('starts in loading state and resolves to data', async () => {
      api.get.mockResolvedValueOnce({
        data: { total: 2, runs: PAGE_1_RUNS, nextCursor: null },
      });

      const { result } = renderHook(() => usePaginatedReports({}));

      // Immediately after mount — should be loading
      expect(result.current.loading).toBe(true);

      await waitFor(() => expect(result.current.loading).toBe(false));

      expect(result.current.runs).toEqual(PAGE_1_RUNS);
      expect(result.current.total).toBe(2);
      expect(result.current.error).toBeNull();
    });

    it('sets hasMore=false when nextCursor is null', async () => {
      api.get.mockResolvedValueOnce({
        data: { total: 2, runs: PAGE_1_RUNS, nextCursor: null },
      });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      expect(result.current.hasMore).toBe(false);
    });

    it('sets hasMore=true when nextCursor is not null', async () => {
      api.get.mockResolvedValueOnce({
        data: { total: 4, runs: PAGE_1_RUNS, nextCursor: '2025-11-30T09:00:00Z' },
      });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      expect(result.current.hasMore).toBe(true);
    });

    it('calls the correct URL with default limit', async () => {
      api.get.mockResolvedValueOnce({ data: { total: 0, runs: [], nextCursor: null } });

      renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(api.get).toHaveBeenCalled());

      const calledUrl = api.get.mock.calls[0][0];
      expect(calledUrl).toContain('/reports?');
      expect(calledUrl).toContain('limit=40');
    });

    it('includes filter params in the request URL', async () => {
      api.get.mockResolvedValueOnce({ data: { total: 0, runs: [], nextCursor: null } });

      renderHook(() =>
        usePaginatedReports({ projectId: 'uuid-123', mode: 'steady_state', compliance: 'pass' })
      );
      await waitFor(() => expect(api.get).toHaveBeenCalled());

      const calledUrl = api.get.mock.calls[0][0];
      expect(calledUrl).toContain('projectId=uuid-123');
      expect(calledUrl).toContain('mode=steady_state');
      expect(calledUrl).toContain('compliance=pass');
    });

    it('sets error when the API call fails', async () => {
      api.get.mockRejectedValueOnce({
        response: { data: { error: 'Failed to load reports' } },
      });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      expect(result.current.error).toBe('Failed to load reports');
      expect(result.current.runs).toEqual([]);
    });

    it('uses fallback error message when API error lacks a body', async () => {
      api.get.mockRejectedValueOnce(new Error('Network Error'));

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      expect(result.current.error).toBeTruthy();
    });
  });

  // ── loadMore ──────────────────────────────────────────────────────────────

  describe('loadMore', () => {
    it('appends page 2 runs to page 1 runs', async () => {
      api.get
        .mockResolvedValueOnce({
          data: { total: 4, runs: PAGE_1_RUNS, nextCursor: '2025-11-30T09:00:00Z' },
        })
        .mockResolvedValueOnce({
          data: { total: 4, runs: PAGE_2_RUNS, nextCursor: null },
        });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      act(() => { result.current.loadMore(); });
      await waitFor(() => expect(result.current.loadingMore).toBe(false));

      expect(result.current.runs).toHaveLength(4);
      expect(result.current.runs.map(r => r.id)).toEqual(['run-1', 'run-2', 'run-3', 'run-4']);
    });

    it('passes the cursor param when loading more', async () => {
      const cursor = '2025-11-30T09:00:00Z';
      api.get
        .mockResolvedValueOnce({ data: { total: 4, runs: PAGE_1_RUNS, nextCursor: cursor } })
        .mockResolvedValueOnce({ data: { total: 4, runs: PAGE_2_RUNS, nextCursor: null } });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      act(() => { result.current.loadMore(); });
      await waitFor(() => expect(result.current.loadingMore).toBe(false));

      const secondCallUrl = api.get.mock.calls[1][0];
      expect(secondCallUrl).toContain('cursor=');
      expect(secondCallUrl).toContain(encodeURIComponent(cursor));
    });

    it('deduplicates runs by id if the same run appears in two pages', async () => {
      const duplicateRun = PAGE_1_RUNS[1]; // run-2 appears in both pages
      api.get
        .mockResolvedValueOnce({ data: { total: 3, runs: PAGE_1_RUNS, nextCursor: '2025-11-30T09:00:00Z' } })
        .mockResolvedValueOnce({
          data: {
            total:      3,
            runs:       [duplicateRun, ...PAGE_2_RUNS],
            nextCursor: null,
          },
        });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      act(() => { result.current.loadMore(); });
      await waitFor(() => expect(result.current.loadingMore).toBe(false));

      const ids = result.current.runs.map(r => r.id);
      const uniqueIds = [...new Set(ids)];
      expect(ids).toEqual(uniqueIds); // no duplicates
    });

    it('sets hasMore=false after the last page', async () => {
      api.get
        .mockResolvedValueOnce({ data: { total: 4, runs: PAGE_1_RUNS, nextCursor: '2025-11-30T09:00:00Z' } })
        .mockResolvedValueOnce({ data: { total: 4, runs: PAGE_2_RUNS, nextCursor: null } });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      act(() => { result.current.loadMore(); });
      await waitFor(() => expect(result.current.loadingMore).toBe(false));

      expect(result.current.hasMore).toBe(false);
    });

    it('is a no-op when hasMore is false', async () => {
      api.get.mockResolvedValueOnce({ data: { total: 2, runs: PAGE_1_RUNS, nextCursor: null } });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      expect(result.current.hasMore).toBe(false);
      const callCount = api.get.mock.calls.length;

      act(() => { result.current.loadMore(); });
      // No additional API call should have been made
      expect(api.get.mock.calls.length).toBe(callCount);
    });

    it('is a no-op while a fetch is already in flight', async () => {
      let resolveFirst;
      const firstPromise = new Promise(res => { resolveFirst = res; });

      api.get.mockImplementationOnce(() => firstPromise);

      const { result } = renderHook(() => usePaginatedReports({}));

      // Trigger a second loadMore before the first resolves — should be ignored
      act(() => { result.current.loadMore(); });

      expect(api.get.mock.calls.length).toBe(1); // only one call total

      act(() => {
        resolveFirst({ data: { total: 2, runs: PAGE_1_RUNS, nextCursor: null } });
      });
    });
  });

  // ── refresh ───────────────────────────────────────────────────────────────

  describe('refresh', () => {
    it('resets runs, cursor, and triggers a reload', async () => {
      api.get
        .mockResolvedValueOnce({ data: { total: 2, runs: PAGE_1_RUNS, nextCursor: null } })
        .mockResolvedValueOnce({ data: { total: 2, runs: PAGE_1_RUNS, nextCursor: null } });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      expect(result.current.runs).toHaveLength(2);

      act(() => { result.current.refresh(); });

      // Should have re-triggered loading
      await waitFor(() => expect(api.get.mock.calls.length).toBe(2));
    });

    it('clears the run list immediately on refresh', async () => {
      api.get.mockResolvedValueOnce({ data: { total: 2, runs: PAGE_1_RUNS, nextCursor: null } });

      const { result } = renderHook(() => usePaginatedReports({}));
      await waitFor(() => expect(result.current.loading).toBe(false));

      // Set up second call to never resolve (so we can observe the cleared state)
      api.get.mockImplementationOnce(() => new Promise(() => {}));

      act(() => { result.current.refresh(); });

      // After refresh the old runs should have been cleared
      expect(result.current.runs).toHaveLength(0);
    });
  });

  // ── filter changes ────────────────────────────────────────────────────────

  describe('filter changes', () => {
    it('resets and reloads when projectId changes', async () => {
      api.get
        .mockResolvedValue({ data: { total: 1, runs: [PAGE_1_RUNS[0]], nextCursor: null } });

      const { result, rerender } = renderHook(
        ({ projectId }) => usePaginatedReports({ projectId }),
        { initialProps: { projectId: 'proj-1' } }
      );
      await waitFor(() => expect(result.current.loading).toBe(false));

      const callsBefore = api.get.mock.calls.length;

      rerender({ projectId: 'proj-2' });
      await waitFor(() => expect(api.get.mock.calls.length).toBeGreaterThan(callsBefore));

      const lastUrl = api.get.mock.calls[api.get.mock.calls.length - 1][0];
      expect(lastUrl).toContain('projectId=proj-2');
    });

    it('resets and reloads when compliance filter changes', async () => {
      api.get.mockResolvedValue({ data: { total: 0, runs: [], nextCursor: null } });

      const { result, rerender } = renderHook(
        ({ compliance }) => usePaginatedReports({ compliance }),
        { initialProps: { compliance: null } }
      );
      await waitFor(() => expect(result.current.loading).toBe(false));

      const callsBefore = api.get.mock.calls.length;
      rerender({ compliance: 'pass' });
      await waitFor(() => expect(api.get.mock.calls.length).toBeGreaterThan(callsBefore));

      const lastUrl = api.get.mock.calls[api.get.mock.calls.length - 1][0];
      expect(lastUrl).toContain('compliance=pass');
    });
  });

  // ── sentinelRef ───────────────────────────────────────────────────────────

  describe('sentinelRef', () => {
    it('returns a function (callback ref)', () => {
      api.get.mockResolvedValue({ data: { total: 0, runs: [], nextCursor: null } });
      const { result } = renderHook(() => usePaginatedReports({}));
      expect(typeof result.current.sentinelRef).toBe('function');
    });

    it('creates an IntersectionObserver when a DOM node is passed', async () => {
      api.get.mockResolvedValue({ data: { total: 0, runs: [], nextCursor: null } });

      const { result } = renderHook(() => usePaginatedReports({}));

      const fakeNode = document.createElement('div');
      act(() => { result.current.sentinelRef(fakeNode); });

      expect(global.IntersectionObserver).toHaveBeenCalled();
      const observerInstance = global.IntersectionObserver.mock.results[0].value;
      expect(observerInstance.observe).toHaveBeenCalledWith(fakeNode);
    });

    it('does not throw when called with null (node unmount)', () => {
      api.get.mockResolvedValue({ data: { total: 0, runs: [], nextCursor: null } });
      const { result } = renderHook(() => usePaginatedReports({}));
      expect(() => act(() => result.current.sentinelRef(null))).not.toThrow();
    });
  });

  // ── exposed API surface ───────────────────────────────────────────────────

  describe('hook return shape', () => {
    it('exposes all required properties', async () => {
      api.get.mockResolvedValue({ data: { total: 0, runs: [], nextCursor: null } });
      const { result } = renderHook(() => usePaginatedReports({}));

      expect(result.current).toHaveProperty('runs');
      expect(result.current).toHaveProperty('total');
      expect(result.current).toHaveProperty('loading');
      expect(result.current).toHaveProperty('loadingMore');
      expect(result.current).toHaveProperty('error');
      expect(result.current).toHaveProperty('hasMore');
      expect(result.current).toHaveProperty('loadMore');
      expect(result.current).toHaveProperty('refresh');
      expect(result.current).toHaveProperty('sentinelRef');
    });
  });
});
