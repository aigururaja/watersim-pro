/**
 * WaterSim Pro — useVirtualScroll hook tests
 * Session 16: Performance — virtual scrolling primitive
 *
 * Run with:  npx vitest run
 * Framework: Vitest + @testing-library/react-hooks
 *
 * Install peer deps if not present:
 *   npm i -D @testing-library/react @testing-library/react-hooks jsdom
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useVirtualScroll } from '../../hooks/useVirtualScroll';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const ITEMS_100 = Array.from({ length: 100 }, (_, i) => ({ id: i, label: `Row ${i}` }));
const ITEMS_10  = Array.from({ length: 10  }, (_, i) => ({ id: i, label: `Row ${i}` }));

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('useVirtualScroll', () => {
  describe('initial state', () => {
    it('returns the correct totalHeight for all items', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight: 520 })
      );
      expect(result.current.totalHeight).toBe(100 * 52);
    });

    it('starts with scrollTop = 0 and renders from the first item', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight: 520 })
      );
      expect(result.current.firstVisible).toBe(0);
    });

    it('renders only a viewport-sized slice of items on mount (+ overscan)', () => {
      const itemHeight      = 52;
      const containerHeight = 520;  // fits exactly 10 rows
      const overscan        = 5;

      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight, overscan, containerHeight })
      );

      // Should render at most: visibleRows + overscan rows above + overscan rows below
      const maxExpected = Math.ceil(containerHeight / itemHeight) + overscan * 2 + 1;
      expect(result.current.visibleItems.length).toBeLessThanOrEqual(maxExpected);
    });

    it('renders ALL items when list is smaller than the container', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_10, itemHeight: 52, containerHeight: 600 })
      );
      // 10 items × 52px = 520px < 600px container — all items visible
      expect(result.current.visibleItems.length).toBe(10);
    });

    it('totalHeight is 0 for an empty item list', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: [], itemHeight: 52, containerHeight: 520 })
      );
      expect(result.current.totalHeight).toBe(0);
      expect(result.current.visibleItems).toHaveLength(0);
    });
  });

  describe('visible item shape', () => {
    it('each visible item has { item, index, top }', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight: 520 })
      );
      const first = result.current.visibleItems[0];
      expect(first).toHaveProperty('item');
      expect(first).toHaveProperty('index');
      expect(first).toHaveProperty('top');
    });

    it('item.top equals index × itemHeight', () => {
      const itemHeight = 56;
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight, containerHeight: 520 })
      );
      for (const vi of result.current.visibleItems) {
        expect(vi.top).toBe(vi.index * itemHeight);
      }
    });

    it('visibleItems indices are consecutive', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight: 520 })
      );
      const indices = result.current.visibleItems.map(vi => vi.index);
      for (let i = 1; i < indices.length; i++) {
        expect(indices[i]).toBe(indices[i - 1] + 1);
      }
    });

    it('preserves original data on each visibleItem.item', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight: 520 })
      );
      const first = result.current.visibleItems[0];
      expect(first.item).toEqual(ITEMS_100[first.index]);
    });
  });

  describe('scrolling behaviour', () => {
    it('advances visible window after a scroll event', () => {
      const itemHeight      = 52;
      const containerHeight = 520;

      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight, containerHeight })
      );

      const initialFirstIndex = result.current.firstVisible;

      // Simulate scrolling down by 10 rows (520 px)
      act(() => {
        const onScroll = result.current.containerProps.onScroll;
        onScroll({ currentTarget: { scrollTop: 520 } });
      });

      expect(result.current.firstVisible).toBeGreaterThan(initialFirstIndex);
    });

    it('clamps lastVisible to the last item index when scrolled to bottom', () => {
      const itemHeight      = 52;
      const containerHeight = 520;

      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight, containerHeight })
      );

      act(() => {
        const onScroll = result.current.containerProps.onScroll;
        // Scroll way past the bottom
        onScroll({ currentTarget: { scrollTop: 999_999 } });
      });

      expect(result.current.lastVisible).toBe(ITEMS_100.length - 1);
    });

    it('firstVisible is 0 after scrolling back to the top', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight: 520 })
      );

      act(() => {
        result.current.containerProps.onScroll({ currentTarget: { scrollTop: 1040 } });
      });

      act(() => {
        result.current.containerProps.onScroll({ currentTarget: { scrollTop: 0 } });
      });

      expect(result.current.firstVisible).toBe(0);
    });

    it('offsetY equals firstVisible × itemHeight', () => {
      const itemHeight = 52;
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight, containerHeight: 520 })
      );

      act(() => {
        result.current.containerProps.onScroll({ currentTarget: { scrollTop: 520 } });
      });

      expect(result.current.offsetY).toBe(result.current.firstVisible * itemHeight);
    });
  });

  describe('containerProps', () => {
    it('returns an onScroll handler', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight: 520 })
      );
      expect(typeof result.current.containerProps.onScroll).toBe('function');
    });

    it('includes style with overflowY:auto and the given containerHeight', () => {
      const containerHeight = 480;
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100, itemHeight: 52, containerHeight })
      );
      expect(result.current.containerProps.style.overflowY).toBe('auto');
      expect(result.current.containerProps.style.height).toBe(containerHeight);
    });
  });

  describe('default values', () => {
    it('uses itemHeight=52 by default', () => {
      const { result } = renderHook(() =>
        useVirtualScroll({ items: ITEMS_100 })
      );
      expect(result.current.totalHeight).toBe(100 * 52);
    });

    it('renders without error when called with no options', () => {
      expect(() => renderHook(() => useVirtualScroll({}))).not.toThrow();
    });
  });
});
